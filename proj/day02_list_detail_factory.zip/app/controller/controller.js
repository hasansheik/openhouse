( function() {
		function myFun($scope, myfactroy) {
			$scope.herolist = myfactroy.heros;
			$scope.val = "id";
			$scope.reverse = false;
			$scope.filterFun = function(prop) {
				$scope.val = prop;
				$scope.reverse = !$scope.reverse;
			};
		}
		angular.module("app").controller("heroController", myFun);
	}());
