( function() {
		function myFun($scope, $routeParams, myfactroy) {
			$scope.val = "id";
			$scope.reverse = false;
			$scope.hid = $routeParams.id;
			$scope.selectedMovieList = null;
			//-----------------------------
			$scope.filterFun = function(prop) {
				$scope.val = prop;
				$scope.reverse = !$scope.reverse;
			};
			//-----------------------------
			function init() {
				for(var i = 0 ; i < $scope.herolist.length; i++){
					if($scope.herolist[i].id === parseInt($scope.hid)){
						$scope.selectedMovieList = $scope.herolist[i].movieslist;
					}
				}
			}
			//-----------------------------
			$scope.herolist = myfactroy.heros;
			init();
		}
		angular.module("app").controller("movieController", myFun);
	}());
