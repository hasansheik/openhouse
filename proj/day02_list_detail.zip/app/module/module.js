(function(){
	angular.module("app",["ngRoute"])
	.config(function($routeProvider){
		$routeProvider
		.when("/",{
			controller : "heroController",
			templateUrl : "app/views/heroList.html"
		});
	});
	
}());
