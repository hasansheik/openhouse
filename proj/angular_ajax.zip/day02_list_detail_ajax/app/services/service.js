( function() {
	function myService($http){
		this.getHeros = function(){
			return $http.get("data/heros.json");
			//  return $http.get("http://learnjs.in/openhouse/heros.json");
		}
	}
	angular.module("app").service("myservice", myService);
}());
