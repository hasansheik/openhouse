( function() {
		function myFun($scope, myservice) {
			/*
			 */
			myservice.getHeros()
			.success(function(data,status,xhr){
				$scope.herolist = data.heros;
			})
			.error(function(data, staus){
				console.log(data)
				console.log(status)
			})
			
			/*
			myservice.getHeros()
			.then(successFun, failFun);
			function successFun(){
				
			}
			function failFun(){
				
			};
			 */
			
			/*
			myservice.getHeros()
			myservice.getHeroins()
			.then(successFun, failFun);
			function successFun(){
				
			}
			function failFun(){
				
			};
			 */
			
			$scope.val = "id";
			$scope.reverse = false;
			$scope.filterFun = function(prop) {
				$scope.val = prop;
				$scope.reverse = !$scope.reverse;
			};
		}
		angular.module("app").controller("heroController", myFun);
	}());
