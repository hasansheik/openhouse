( function() {
		function myFun($scope, $routeParams, myservice) {
			$scope.val = "id";
			$scope.reverse = false;
			$scope.hid = $routeParams.id;
			$scope.selectedMovieList = null;
			//-----------------------------
			$scope.filterFun = function(prop) {
				$scope.val = prop;
				$scope.reverse = !$scope.reverse;
			};
			//-----------------------------
			/*
			 */
			myservice.getHeros()
			.success(function(data,status,xhr){
				$scope.herolist = data.heros;
				init();
			})
			.error(function(data, staus){
				console.log(data)
				console.log(status)
			})
			//-----------------------------
			function init() {
				for(var i = 0 ; i < $scope.herolist.length; i++){
					if($scope.herolist[i].id === parseInt($scope.hid)){
						$scope.selectedMovieList = $scope.herolist[i].movieslist;
					}
				}
			}
			//-----------------------------
			
		}
		angular.module("app").controller("movieController", myFun);
	}());
