(function(){
	angular.module("app",["ngRoute"])
	.config(function($routeProvider){
		$routeProvider
		.when("/",{
			controller : "heroController",
			templateUrl : "app/views/heroList.html"
		})
		.when("/movielist/:id",{
			controller : "movieController",
			templateUrl : "app/views/movieList.html"
		});
	});
	
}());
